from typing import Tuple
from maze import play as pl
import maze as m

Movement = (pl.console.UnionStr("home", "h"), pl.console.UnionStr("back", "undo", "u"),
            pl.console.UnionStr("redo", "r"), pl.console.UnionStr("exit", "e", "quit", "q", "end"))
info = """Maze?
play[p]\texit[e, quit, q, end]"""


class Level(pl.console.PageContent):
    def __init__(self, data):
        super().__init__(data)
        self.keys = {"w": (0, -1), "a": (-1, 0), "s": (0, 1), "d": (1, 0)}

    def get_movement(self):
        path = input("move: ")
        current = (0, 0)

        def update(b: Tuple[int, int], n: Tuple[int, int]):
            return b[0] + n[0], b[1] + n[1]
        for letter in path:
            if letter in self.keys:
                current = update(current, self.keys[letter])
        return current
    
    def get(self):
        level_manager = m.levels.LevelsManager()
        reader = pl.board_reader.BoardReader(level_manager.level.board, level_manager.level.player.x,
                                             level_manager.level.player.y)
        print(str(reader))
        while not level_manager.finished_all:
            pl.console.clear()
            print(str(reader))
            path = self.get_movement()
            reader = pl.board_reader.BoardReader(level_manager.level.cords_move_player(*path),
                                                 level_manager.level.player.x, level_manager.level.player.y)
            level_manager.soft_next()
            if level_manager.finished_all:
                break
        self.end()

    @staticmethod
    def end():
        pl.console.clear()
        input("1")
        pl.console.clear()
        input("1/")
        pl.console.clear()
        input("1/0")
        pl.console.clear()
        input("1/0=")
        pl.console.clear()
        input("1/0=.")
        pl.console.clear()
        input("1/0=..")
        pl.console.clear()
        input("1/0=...")
        pl.console.clear()
        input("1/0=0?")
        pl.console.clear()
        input("""Traceback (most recent call last):
  File "<input: player>", line (last), in <module "maze?">
ZeroDivisionError: division by zero""")
        pl.console.clear()
        input("the end!\nthanks for playing")
        exit()


Main = pl.console.Page(pl.console.ClearContent(info), {pl.console.UnionStr("play", "p"): pl.console.Page(Level(None))})


def main():
    pl.console.operate(pl.console.Pages(Main, *Movement))


if __name__ == '__main__':
    main()
