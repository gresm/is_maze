from typing import List, Optional, Tuple, Union
from enum import Enum
import copy as c


class FieldData:
    def __init__(self):
        self.connected_to_field: bool = False
        self.connected: bool = False
        self.x_pos: int = 0
        self.y_pos: int = 0
        self.field: "Optional[Field]" = None

    def connect_to_field(self, field: "Field"):
        self.connected_to_field = True
        self.field = field
        self.x_pos = self.field.x_pos
        self.y_pos = self.field.y_pos

    def connect_to_board(self):
        self.connected = True
        self.x_pos = self.field.x_pos
        self.y_pos = self.field.y_pos


class Field:
    def __init__(self, data: Optional[FieldData] = None):
        self.x_pos: int = 0
        self.y_pos: int = 0
        self.board: "Optional[Board2D]" = None
        self.connected: bool = False
        self.data: FieldData = data if data else FieldData()
        self.data.connect_to_field(self)

    def connect(self, board, x_pos: int, y_pos: int):
        self.connected = True
        self.board = board
        self.x_pos = x_pos
        self.y_pos = y_pos
        self.data.connect_to_board()

    def get_field(self, x: int, y: int) -> Union["Field", bool]:
        if self.connected:
            return self.board.get(self.x_pos+x, self.y_pos+y)
        else:
            raise ValueError("Not connected")

    def set_field(self, x: int, y: int, field: "Field") -> bool:
        if self.connected:
            return self.board.set(self.x_pos+x, self.y_pos+y, field)
        else:
            raise ValueError("Not connected")

    def has_field(self, x: int, y: int) -> bool:
        return self.board.in_range(self.x_pos+x, self.y_pos + y)


class RangeTypes(Enum):
    between = 0
    only_left = 1
    only_right = 2
    with_borders = 3


class Range:
    def __init__(self, start, end, range_type: RangeTypes):
        self.start = start
        self.end = end
        self.range_type = range_type

    def __contains__(self, item):
        if self.range_type == RangeTypes.between:
            return self.between(item)
        elif self.range_type == RangeTypes.only_left:
            return self.only_left(item)
        elif self.range_type == RangeTypes.only_right:
            return self.only_right(item)
        elif self.range_type == RangeTypes.with_borders:
            return self.with_borders(item)
        raise ValueError("Incorrect range_type")

    def between(self, v):
        return self.start < v < self.end

    def only_left(self, v):
        return self.start <= v < self.end

    def only_right(self, v):
        return self.start < v <= self.end

    def with_borders(self, v):
        return self.start <= v <= self.end


class Board2D:
    def __init__(self, default: Field, size_x: int, size_y: int):
        board = []
        for y in range(size_y):
            board.append([])
            for x in range(size_x):
                e = c.copy(default)
                e.connect(self, x, y)
                board[y].append(e)
        self.board: List[List[Field]] = board
        self.size_x = size_x
        self.size_y = size_y
        self.default = default
        self.range_x = Range(0, self.size_x, RangeTypes.only_left)
        self.range_y = Range(0, self.size_y, RangeTypes.only_left)

    def __iter__(self) -> "Board2DIterator":
        return Board2DIterator(self).__iter__()

    def in_range(self, x: int, y: int) -> bool:
        return x in self.range_x and y in self.range_y

    def get(self, x: int, y: int) -> Union[Field, bool]:
        try:
            return self.board[x][y]
        except IndexError:
            return False

    def set(self, x: int, y: int, tile: Field) -> bool:
        try:
            self.board[y][x] = tile
            tile.connect(self, x, y)
            return True
        except IndexError:
            return False

    def iter_per_rows(self) -> "Board2DRowsIterator":
        return Board2DRowsIterator(self)


class Board2DRowsIterator:
    def __init__(self, board: Board2D):
        self.board = board
        self.i = 0
        self.c_row: List[Field] = []

    def __iter__(self) -> "Board2DRowsIterator":
        self.i = 0
        return self

    def __next__(self) -> List[Field]:
        if self.i < len(self.board.board):
            self.i += 1
            self.c_row = self.board.board[self.i-1]
            return self.board.board[self.i-1]
        else:
            raise StopIteration


class Board2DLineIterator:
    def __init__(self, row: Board2DRowsIterator):
        self.row = row.c_row
        self.i = 0

    def __iter__(self) -> "Board2DLineIterator":
        self.i = 0
        return self

    def __next__(self) -> Field:
        if self.i < len(self.row):
            self.i += 1
            return self.row[self.i-1]
        else:
            raise StopIteration


class Board2DIterator:
    def __init__(self, board: Board2D, iter_x_range: Optional[Range] = None, iter_y_range: Optional[Range] = None):
        self.iter_y_range = iter_y_range
        self.iter_x_range = iter_x_range
        self.board = board
        self.x_position = -1
        self.y_position = -1

    def __iter__(self) -> "Board2DIterator":
        self.x_position = 0
        self.y_position = 0
        return self

    def __next__(self) -> Tuple[int, int, Field]:
        x = self.x_position
        y = self.y_position
        if self.x_position == -1 or self.y_position == -1:
            raise StopIteration
        if self.iter_x_range:
            if self.x_position not in self.iter_x_range:
                self.y_position += 1
                self.x_position = 0
                x = 0
        else:
            if self.x_position >= self.board.size_x:
                self.y_position += 1
                self.x_position = 0
                x = 0
        if self.iter_y_range:
            if self.y_position not in self.iter_y_range:
                raise StopIteration
        else:
            if self.y_position >= self.board.size_y:
                raise StopIteration
        f = self.board.get(x, y)
        if not f:
            raise StopIteration
        self.x_position += 1
        return x, y, f
