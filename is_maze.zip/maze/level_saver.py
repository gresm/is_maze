from typing import Dict, Union, List
from . import non_euclid_board as nb
from . import settings as ss
from . import board2d as b
import json as j


class Space:
    def __init__(self, board: b.Board2D):
        self.board = board
        self.id_gen = 0
        self.boards: Dict[str, b.Board2D] = {}
        self.add_board(board)
        self.main: str = "0"

    def add_board(self, board: b.Board2D):
        self.boards[str(self.id_gen)] = board
        self.id_gen += 1
        return str(self.id_gen-1)

    def save_board(self, name: str) -> dict:
        ret = {"version": ss.version, "main": name}
        lev = {}
        for i in self.boards:
            board = BoardSaver(self.boards[i], self)
            lev[i] = board.save()
        ret["levels"] = lev
        return ret

    def save(self) -> dict:
        return self.save_board(self.main)


class BoardSaver:
    def __init__(self, board: b.Board2D, space: Space):
        self.space = space
        self.board = board

    def save_board(self) -> List[list]:
        board = self.board.board
        new_b = []
        for y in range(len(board)):
            new_b.append([])
            for x in range(len(board[y])):
                # noinspection PyTypeChecker
                f = FieldSaver(board[y][x].data, self.space)
                new_b[y].append(f.save())
        return new_b

    def save(self) -> dict:
        ret = {"board": self.save_board(), "size_x": self.board.size_x, "size_y": self.board.size_y}
        return ret


class FieldSaver:
    def __init__(self, field: nb.FieldInfo, space: Space):
        self.field = field
        self.space = space

    def save(self) -> dict:
        rend: Dict[str, Union[int, str]] = {}
        ret: Dict[str, Union[str, bool, Dict[str, Union[int, str]]]] = {}
        if self.field.field_type == nb.FieldTypes.render:
            r = self.field.render_info
            nam: str = ""
            if r.board not in self.space.boards.values():
                nam = self.space.add_board(r.board)
            else:
                for i in self.space.boards:
                    if self.space.boards[i] is r.board:
                        nam = i
                        break
            rend["board"] = nam
            rend["x"] = r.x
            rend["y"] = r.y
            ret["render"] = rend
        ret["type"] = self.field.field_type.name
        ret["texture"] = self.field.simpled_texture_type.name
        ret["collide"] = self.field.is_blocking
        return ret


def save(board: b.Board2D):
    space = Space(board)
    return j.dumps(space.save(), indent=2)


def save_to_file(board: b.Board2D, file: str):
    with open(file, "w") as file:
        file.write(save(board))
