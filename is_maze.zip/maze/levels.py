from typing import List, Tuple
from . import level_loader as ll
from . import entities as ent
from . import settings as st


def load_level(level: str) -> ent.Game:
    b = ll.load(level)
    l_info: Tuple[int, int]
    try:
        l_info = st.levels[level]
    except KeyError:
        raise ll.LoadLevelError
    pl = ent.Player(l_info[0], l_info[1])
    g = ent.Game(pl, b, st.render_distance)
    return g


Levels: List[str] = ["level.json", "level2.json", "level3.json", "level4.json", "level5.json"]


class LevelsManager:
    def __init__(self):
        self.current = 0
        self.level = load_level(Levels[self.current])
        self.finished_all: bool = self.current >= len(Levels)

    def next_level(self) -> bool:
        self.current += 1
        self.finished_all = self.current >= len(Levels)
        if not self.finished_all:
            self.level = load_level(Levels[self.current])
            return True
        return False

    def soft_next(self) -> bool:
        if self.level.solved:
            return self.next_level()
        return False
