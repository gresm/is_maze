from typing import Optional
from enum import Enum
from maze import board2d as b
import copy as c


class FieldTypes(Enum):
    floor = 0
    wall = 1
    void = 2
    render = 3

    @classmethod
    def get_by_name(cls, name: str) -> Optional["FieldTypes"]:
        for e in cls:
            if e.name == name:
                return e
        return None


class SimpledTexturesType(Enum):
    floor = 0
    wall = 1
    void = 2
    win = 3

    @classmethod
    def get_by_name(cls, name: str) -> Optional["SimpledTexturesType"]:
        for e in cls:
            if e.name == name:
                return e
        return None


class TexturesType(Enum):
    floor = 0
    void = 1
    # Syntax:
    #   u
    #  l r
    #   d
    # Queue:
    #    l u d r
    wall_0_0_0_0 = 2
    wall_0_0_0_1 = 3
    wall_0_0_1_0 = 4
    wall_0_0_1_1 = 5
    wall_0_1_0_0 = 6
    wall_0_1_0_1 = 7
    wall_0_1_1_0 = 8
    wall_0_1_1_1 = 9
    wall_1_0_0_0 = 10
    wall_1_0_0_1 = 11
    wall_1_0_1_0 = 12
    wall_1_0_1_1 = 13
    wall_1_1_0_0 = 14
    wall_1_1_0_1 = 15
    wall_1_1_1_0 = 16
    wall_1_1_1_1 = 17
    win = 18


class RenderInfo:
    def __init__(self, board: b.Board2D, x: int, y: int):
        self.board = board
        self.x = x
        self.y = y
        self.first: bool = True

    def rep(self):
        ret = RenderInfo(self.board, self.x, self.y)
        ret.first = False
        return ret


class FieldInfo(b.FieldData):
    def __init__(self, field_type: FieldTypes, texture_type: SimpledTexturesType,
                 render_info: Optional[RenderInfo] = None, is_blocking: bool = False):
        super(FieldInfo, self).__init__()

        self.field_type = field_type
        self.light_level: int = 0
        self.simpled_texture_type: SimpledTexturesType = texture_type
        self.texture_type: Optional[TexturesType] = None
        self.render_info: Optional[RenderInfo] = render_info
        self.is_blocking = is_blocking
        if self.field_type == FieldTypes.render and not render_info:
            raise ValueError("'render_info' not assigned")

    def connect_to_board(self):
        super(FieldInfo, self).connect_to_board()
        self.update_texture()

    def get_texture(self) -> TexturesType:
        if not self.connected:
            raise ValueError("Not connected")
        if self.simpled_texture_type == SimpledTexturesType.floor:
            return TexturesType.floor
        elif self.simpled_texture_type == SimpledTexturesType.void:
            return TexturesType.void
        elif self.simpled_texture_type == SimpledTexturesType.win:
            return TexturesType.win
        elif self.simpled_texture_type == SimpledTexturesType.wall:
            le = int(self.field.has_field(-1, 0))
            up = int(self.field.has_field(0, 1))
            do = int(self.field.has_field(0, -1))
            ri = int(self.field.has_field(1, 0))
            s = f"wall_{le}_{up}_{do}_{ri}"
            ret = getattr(TexturesType, s, None)
            if ret:
                return ret
            else:
                raise ValueError("Unknown error")
        else:
            raise ValueError("Invalid Texture Type: " + str(self.simpled_texture_type))

    def update_texture(self):
        self.texture_type = self.get_texture()


class NonEuclidBoard:
    def __init__(self, board: b.Board2D, render_distance: int):
        self.cached_board = board
        self.board: b.Board2D = c.deepcopy(board)
        self.rendered_board: Optional[b.Board2D] = None
        self.render_distance = render_distance

    def start_flood(self, start_x: int, start_y: int) -> b.Board2D:
        self.rendered_board = b.Board2D(b.Field(FieldInfo(FieldTypes.void, SimpledTexturesType.void)),
                                        self.board.size_y, self.board.size_x)
        self.flood_step(start_x, start_y, 0)
        return self.rendered_board

    def flood_step(self, x: int, y: int, step, render_info: Optional[RenderInfo] = None):
        if not self.rendered_board:
            self.rendered_board = b.Board2D(b.Field(FieldInfo(FieldTypes.void, SimpledTexturesType.void)),
                                            self.board.size_y, self.board.size_x)

        if not step == -1 and step >= self.render_distance:
            return

        if render_info:
            new_field = render_info.board.get(render_info.x, render_info.y)
            if render_info.first:
                x = render_info.x
                y = render_info.y
        else:
            new_field = self.board.get(x, y)

        old_field = self.rendered_board.get(x, y)
        if not (new_field and old_field):
            return

        # noinspection PyTypeHints
        new_field.data: FieldInfo
        # noinspection PyTypeHints
        old_field.data: FieldInfo

        if new_field.data.field_type == FieldTypes.void:
            return

        elif new_field.data.field_type == FieldTypes.floor:
            if old_field.data.field_type == FieldTypes.void:
                new_field.data.light_level = self.render_distance - step
                self.rendered_board.set(x, y, new_field)
                self.flood_spread(x, y, step, render_info)
            else:
                if self.render_distance - step > old_field.data.light_level:
                    new_field.data.light_level = self.render_distance - step
                    self.rendered_board.set(x, y, new_field)
                    self.flood_spread(x, y, step, render_info)

        elif new_field.data.field_type == FieldTypes.wall:
            if old_field.data.field_type == FieldTypes.void or self.render_distance - step > old_field.data.light_level:
                new_field.data.light_level = self.render_distance - step
                self.rendered_board.set(x, y, new_field)

        elif new_field.data.field_type == FieldTypes.render:
            if old_field.data.field_type == FieldTypes.void or self.render_distance - step > old_field.data.light_level:
                new_field.data.light_level = self.render_distance - step
                self.rendered_board.set(x, y, new_field)
                self.flood_spread(x, y, step, new_field.data.render_info)

        else:
            raise ValueError("Incorrect field type")

    def flood_spread(self, x: int, y: int, step, render_info: Optional[RenderInfo] = None):
        if render_info:
            self.flood_step(x - 1, 0, step + 1, render_info.rep())
            self.flood_step(x, y + 1, step + 1, render_info.rep())
            self.flood_step(x + 1, y, step + 1, render_info.rep())
            self.flood_step(x, y - 1, step + 1, render_info.rep())
        else:
            self.flood_step(x - 1, 0, step + 1)
            self.flood_step(x, y + 1, step + 1)
            self.flood_step(x + 1, y, step + 1)
            self.flood_step(x, y - 1, step + 1)


DEFAULT = b.Field(FieldInfo(FieldTypes.void, SimpledTexturesType.void))
