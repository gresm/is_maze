from typing import Optional
from . import non_euclid_board as nb
from . import board2d as b
from enum import Enum


class MoveDirection(Enum):
    left = 0
    up = 1
    down = 2
    right = 3
    none = 4


class Player:
    def __init__(self, spawn_x, spawn_y):
        self.x = spawn_x
        self.y = spawn_y
        self.connected: bool = False
        self.level: Optional["Level"] = None
        self.game: Optional["Game"] = None

    def connect(self, game: "Game"):
        self.game = game
        self.level = game.level
        self.connected = True

    def try_move(self, x: int, y: int):
        s_x = self.x + x
        s_y = self.y + y

        field = self.level.board.get(s_x, s_y)
        # noinspection PyTypeHints
        field.data: nb.FieldInfo

        c_field = self.level.board.get(self.x, self.y)
        # noinspection PyTypeHints
        c_field.data: nb.FieldInfo

        if not c_field:
            return

        if c_field.data.field_type == nb.FieldTypes.render:
            self.x = c_field.data.render_info.x
            self.y = c_field.data.render_info.y
            self.level.load_level(c_field.data.render_info.board)
            self.try_move(x, y)
        elif field and not field.data.is_blocking:
            self.x = s_x
            self.y = s_y

    def can_move_to(self, x: int, y: int) -> bool:
        s_x = self.x + x
        s_y = self.y + y

        f = self.level.board.get(s_x, s_y)
        # noinspection PyTypeHints
        f.data: nb.FieldInfo

        f_2 = self.level.board.get(self.x, self.y)
        # noinspection PyTypeHints
        f_2.data: nb.FieldInfo

        if not f_2 or not f:
            return False

        if f_2.data.field_type == nb.FieldTypes.render:
            r = f_2.data.render_info
            f_3 = r.board.get(r.x, r.y)
            # noinspection PyTypeHints
            f_3.data: nb.FieldInfo
            return f_3.data.is_blocking if f_3 else False
        else:
            return f.data.is_blocking

    def can_move(self, direction: MoveDirection):
        if direction == MoveDirection.left:
            self.can_move_to(-1, 0)
        elif direction == MoveDirection.up:
            self.can_move_to(0, 1)
        elif direction == MoveDirection.down:
            self.can_move_to(0, -1)
        elif direction == MoveDirection.right:
            self.can_move_to(1, 0)

    def move(self, direction: MoveDirection):
        if direction == MoveDirection.left:
            self.try_move(-1, 0)
        elif direction == MoveDirection.up:
            self.try_move(0, 1)
        elif direction == MoveDirection.down:
            self.try_move(0, -1)
        elif direction == MoveDirection.right:
            self.try_move(1, 0)


class Level:
    def __init__(self, board: b.Board2D, render_distance: int):
        self.board = board
        self.render_distance = render_distance

    def load_level(self, level: b.Board2D):
        self.board = level

    def get_renderer(self) -> nb.NonEuclidBoard:
        return nb.NonEuclidBoard(self.board, self.render_distance)

    def render(self, x, y) -> b.Board2D:
        n = self.get_renderer()
        return n.start_flood(x, y)


class Game:
    def __init__(self, player: Player, level: b.Board2D, render_distance: int):
        self.player = player
        self.render_distance = render_distance
        self.board = level
        self.level = Level(level, render_distance)
        self.player.connect(self)
        self.solved: bool = False

    def move_player(self, direction: MoveDirection) -> b.Board2D:
        self.player.move(direction)
        field = self.level.board.get(self.player.x, self.player.y)
        # noinspection PyTypeHints
        field.data: nb.FieldInfo
        if field and field.data.simpled_texture_type == nb.SimpledTexturesType.win:
            self.solved = True
        return self.level.render(self.player.x, self.player.y)

    def cords_move_player(self, x: int, y: int):
        self.player.try_move(x, y)
        field = self.level.board.get(self.player.x, self.player.y)
        # noinspection PyTypeHints
        field.data: nb.FieldInfo
        if field and field.data.simpled_texture_type == nb.SimpledTexturesType.win:
            self.solved = True
        return self.level.render(self.player.x, self.player.y)

    def finished(self) -> bool:
        return self.solved
