from typing import Dict, Union, List, Optional
import json as j
from . import settings as st
from . import non_euclid_board as nb
from . import board2d as b2


class LoadLevelError(Exception):
    pass


class Space:
    def __init__(self, json: dict):
        self.version: Union[str, List[str]] = json["version"]
        if not st.check_version(self.version):
            raise LoadLevelError("Not supported version")
        self.json = json
        self.levels: Dict[str, "LevelLoader"] = {}
        self.saved_levels: Dict[str, "b2.Board2D"] = {}
        self.main: str = self.json["main"]
        for index in self.json["levels"]:
            self.levels[index] = LevelLoader(self.json["levels"][index], self, index)

    def load_level(self, level_name: str) -> b2.Board2D:
        if level_name in self.saved_levels:
            return self.saved_levels[level_name]
        else:
            level = self.levels[level_name].load()
            return level

    def load(self) -> b2.Board2D:
        return self.load_level(self.main)


class LevelLoader:
    def __init__(self, json: Dict[str, Union[List[List[dict]], int]], space: Space, name: str):
        self.json = json
        self.space = space
        self.name = name
        self.fields: List[List["FieldLoader"]] = []
        self.y_size: int = self.json["size_y"]
        self.x_size: int = self.json["size_x"]
        self.board = self.json["board"]
        for y in range(len(self.board)):
            self.fields.append([])
            for x in range(len(self.board[y])):
                self.fields[y].append(FieldLoader(self.board[y][x], self.space, name))

    def load(self) -> b2.Board2D:
        board = b2.Board2D(nb.DEFAULT, self.x_size, self.y_size)
        self.space.saved_levels[self.name] = board
        for y in range(len(self.board)):
            for x in range(len(self.board[y])):
                load_field = FieldLoader(self.board[y][x], self.space, self.name)
                board.set(x, y, b2.Field(load_field.load()))
        return board


class FieldLoader:
    def __init__(self, json: dict, space: Space, parent: str):
        self.json = json
        self.space = space
        self.parent = parent
        self.type_name: str = self.json["type"]
        self.texture: str = self.json["texture"]
        self.enum_type = nb.FieldTypes.get_by_name(self.type_name)
        self.enum_texture = nb.SimpledTexturesType.get_by_name(self.texture)
        self.collide: bool = self.json["collide"]
        self.render_info: Optional["RenderInfoFieldLoader"] = None

        if not self.enum_type:
            raise LoadLevelError("Invalid light_type")
        if not self.enum_texture:
            raise LoadLevelError("Invalid texture")

        if self.enum_type == nb.FieldTypes.render:
            self.render_info = RenderInfoFieldLoader(self.json["render"], self.space)

    def load(self) -> nb.FieldInfo:
        render = self.render_info.load() if self.render_info else None
        field = nb.FieldInfo(self.enum_type, self.enum_texture, render, self.collide)
        return field


class RenderInfoFieldLoader:
    def __init__(self, json: dict, space: Space):
        self.json = json
        self.space = space
        self.x: int = self.json["x"]
        self.y: int = self.json["y"]
        self.board: str = self.json["board"]

    def get_board(self) -> b2.Board2D:
        if self.board in self.space.saved_levels:
            return self.space.saved_levels[self.board]
        else:
            return self.space.load_level(self.board)

    def load(self) -> nb.RenderInfo:
        return nb.RenderInfo(self.get_board(), self.x, self.y)


def load_as_space(file: str):
    with open(file, "r+") as file:
        try:
            space = Space(j.loads(file.read()))
            return space
        except KeyboardInterrupt as err:
            raise err
        except LoadLevelError as err:
            raise err
        except Exception as err:
            raise LoadLevelError("Failed to load file", err)


def load_from_json(json: dict):
    try:
        space = Space(json)
        return space.load()
    except KeyboardInterrupt as err:
        raise err
    except LoadLevelError as err:
        raise err
    except Exception as err:
        raise LoadLevelError("Failed to load file", err)


def load(file: str):
    with open(file, "r+") as file:
        return load_from_json(j.loads(file.read()))
