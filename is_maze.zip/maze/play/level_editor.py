"""
Tool to edit levels.
At the moment it isn't available in game.
You can save, but to test custom levels you must override old ones.
To change/add/remove levels you need to edit levels.py and setting.py
levels.Levels is list of file paths to levels
To remove level just delete item from this list.
But don't leave it empty!
To add new levels add new item with correct name and in settings.py:
settings.levels is ad dict keys are paths and values are tuples of (spawn_x_pos, spawn_y_pos) for
that level.
Just add new item with proper values, if missing it will crash.
To use this program(python code):
'
from maze.play import level_editor as le, console as c
c.operate(le.Main)
'
"""


from typing import Optional, Callable
from . import board_reader as br
from . import console as cs
from .. import board2d as b
from .. import non_euclid_board as nb
from .. import level_saver as ls
from .. import level_loader as ll


class BoardEditor:
    def __init__(self, size_x: int, size_y: int):
        self.board = b.Board2D(b.Field(nb.FieldInfo(nb.FieldTypes.void, nb.SimpledTexturesType.void)), size_x, size_y)
        self.size_x = size_x
        self.size_y = size_y
        self.select_x: int = 0
        self.select_y: int = 0

    def move(self, x: int, y: int):
        n_x = self.select_x + x
        n_y = self.select_y + y
        if 0 <= n_x < self.size_x and 0 <= n_y < self.size_y:
            self.select_x = n_x
            self.select_y = n_y

    def set(self, f: nb.FieldInfo):
        return self.board.set(self.select_x, self.select_y, b.Field(f))

    @classmethod
    def from_created(cls, board: b.Board2D) -> "BoardEditor":
        ed = cls.__new__(cls)
        ed.board = board
        ed.size_x = board.size_x
        ed.size_y = board.size_y
        ed.select_x = 0
        ed.select_y = 0
        return ed


class Cache:
    def __init__(self):
        self.data: Optional[b.Board2D] = None
        self.editor: Optional[BoardEditor] = None

    def set(self, board: b.Board2D):
        self.data = board
        if self.editor:
            x = self.editor.select_x
            y = self.editor.select_y
            self.editor = BoardEditor.from_created(self.data)
            self.editor.select_x = x
            self.editor.select_y = y
        else:
            self.editor = BoardEditor.from_created(self.data)


class EditPage(cs.PageContent):
    data: Cache

    def get(self):
        edit = self.data.editor
        editing: bool = True
        while editing:
            read = br.BoardReader(edit.board, edit.select_x, edit.select_y)
            cs.clear()
            print(str(read))
            move = cs.UnionStr("move", "m")
            ed_field = cs.UnionStr("edit", "ed")
            save = cs.UnionStr("save", "s")
            leave = cs.UnionStr("leave", "l")
            act = input("move[m] edit[ed] save[s] leave[l]")
            if move == act:
                pth = input("wasd to move(can stack)\n")

                def cha(f, s):
                    return f[0] + s[0], f[1] + s[1]

                m = {'w': (0, -1), 'a': (-1, 0), 's': (0, 1), 'd': (1, 0)}
                n = (0, 0)
                for c in pth:
                    if c in m:
                        n = cha(n, m[c])
                edit.move(*n)
            elif ed_field == act:
                y = cs.UnionStr("yes", "y")
                n = cs.UnionStr("no", "n")
                r_coll = input("field collide yes[y], no[n]")
                f_coll = False
                if r_coll == y:
                    f_coll = True
                elif r_coll == n:
                    f_coll = False
                else:
                    print("invalid answer, set to default: No")
                f_texture: nb.SimpledTexturesType
                f_texture = nb.SimpledTexturesType.get_by_name(input("field texture floor, wall, void, win: "))
                if not f_texture:
                    print("invalid texture name set to default: void")
                    f_texture = nb.SimpledTexturesType.void
                f_type: nb.FieldTypes
                f_type = nb.FieldTypes.get_by_name(input("field type floor, wall, void, render: "))
                if not f_type:
                    print("invalid texture name set to default: void")
                    f_type = nb.FieldTypes.void
                rend: Optional[nb.RenderInfo] = None
                if f_type == nb.FieldTypes.render:
                    x_pos = input("render x_pos: ")
                    try:
                        x_pos = int(x_pos)
                    except ValueError:
                        print("invalid coordinate set to default: 0")
                        x_pos = 0
                    y_pos = input("render y_pos: ")
                    try:
                        y_pos = int(y_pos)
                    except ValueError:
                        print("invalid coordinate set to default: 0")
                        x_pos = 0
                    rend = nb.RenderInfo(edit.board, x_pos, y_pos)
                dat = nb.FieldInfo(f_type, f_texture, rend, f_coll)
                edit.set(dat)

            elif save == act:
                file = input("file:")
                ls.save_to_file(edit.board, file)
            elif leave == act:
                break
            else:
                print("incorrect action")
        return ""


class LoadPage(cs.PageContent):
    data: Cache

    def get(self):
        try:
            board = ll.load(input("file:"))
            self.data.set(board)
            ret = ""
            re = br.BoardReader(board, self.data.editor.select_x, self.data.editor.select_y)
            for r in b.Board2DRowsIterator(board):
                for f in r:
                    ret += re.str_field(f)
                ret += "\n"
            return ret[:-1]
        except ll.LoadLevelError:
            return "failed to load file"
        except FileNotFoundError:
            return "failed to load file"


class NewPage(cs.PageContent):
    data: Cache

    def get(self):
        x_size = 1
        y_size = 1
        x_str = input("x size")
        try:
            x_size = int(x_str)
        except ValueError:
            print("incorrect x size, set to default - 1")
        y_str = input("y size")
        try:
            y_size = int(y_str)
        except ValueError:
            print("incorrect y size, set to default - 1")
        self.data.editor = BoardEditor(x_size, y_size)
        self.data.data = self.data.editor.board
        ret = ""
        re = br.BoardReader(self.data.data, self.data.editor.select_x, self.data.editor.select_y)
        for r in b.Board2DRowsIterator(self.data.data):
            for f in r:
                ret += re.str_field(f)
            ret += "\n"
        return ret[:-1]


_MainCache: Cache = Cache()
_Edit: cs.Page = cs.Page(EditPage(_MainCache))
_Load: cs.Page = cs.Page(LoadPage(_MainCache))
_New: cs.Page = cs.Page(NewPage(_MainCache))

Movement = (cs.UnionStr("home", "h"), cs.UnionStr("back", "undo", "u"), cs.UnionStr("redo", "r"),
            cs.UnionStr("exit", "e", "quit", "q", "end"))

Path = {cs.UnionStr("edit", "ed"): _Edit, cs.UnionStr("load", "l"): _Load, cs.UnionStr("new", "n"): _New}

MainPage: cs.Page = cs.Page(cs.ClearContent("""Level editor
home[h]\texit[e, quit, q, end]
back[undo, u]\tredo[r]
new[n]\tload[l]\tedit[ed]"""),
                            Path)

Main: cs.Pages = cs.Pages(MainPage, *Movement)


operate: Callable = lambda: cs.operate(Main)
