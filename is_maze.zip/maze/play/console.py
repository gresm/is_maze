from typing import Dict, Optional, Any, Union
from .history import History
import os


class ClosedPages(Exception):
    pass


STR = Union["UnionStr", str]


class UnionStr:
    def __init__(self, *args: STR):
        self.args = args

    def __eq__(self, other: str):
        if other in self.args:
            return True
        for e in self.args:
            if other == e:
                return True
        return False

    def __contains__(self, item):
        return self.__eq__(item)

    def __hash__(self):
        return object.__hash__(self)


class Pages:
    def __init__(self, main_page: "Page", home_command: Optional[STR] = None, undo_command: Optional[STR] = None,
                 redo_command: Optional[STR] = None, end_command: Optional[STR] = None):
        self.main_page = main_page
        self.current_page: "Page" = self.main_page
        self.home_command = home_command
        self.undo_command = undo_command
        self.redo_command = redo_command
        self.end_command = end_command
        self.history: History = History()
        self.history.edit(self.current_page)
        self.opened: bool = True

    def __str__(self):
        return str(self.current_page)

    def move_to(self, page: str):
        if not self.opened or page == self.end_command:
            self.opened = False
            raise ClosedPages
        if page == self.home_command:
            self.current_page = self.main_page
            self.history.edit(self.current_page)
        elif page == self.undo_command:
            self.current_page = self.history.back()
        elif page == self.redo_command:
            self.current_page = self.history.forward()
        else:
            self.current_page = self.current_page.move_to(page)
            self.history.edit(self.current_page)


class PageContent:
    def __init__(self, data: Any):
        self.data = data

    def get(self):
        return str(self.data)

    def __str__(self):
        return str(self.get())


class ClearContent(PageContent):
    def __init__(self, data: str):
        super().__init__(data)

    def get(self):
        clear()
        return super(ClearContent, self).get()

    def __str__(self):
        return str(self.get())


class Page:
    def __init__(self, content: PageContent, sub_pages: Optional[Dict[STR, "Page"]] = None):
        self.content = content
        self.sub_pages = sub_pages if sub_pages else {}

    def __str__(self):
        return str(self.content)

    def move_to(self, page: STR):
        for i in self.sub_pages:
            if i == page:
                return self.sub_pages[i]
        return self


supported = {"posix", "nt"}


def check_system():
    return os.name in supported


def clear():
    if os.name == "posix":
        os.system("clear")
    elif os.name == "nt":
        os.system("cls")


def operate(main: Pages):
    try:
        while True:
            print(main)
            main.move_to(input())
    except ClosedPages:
        pass
