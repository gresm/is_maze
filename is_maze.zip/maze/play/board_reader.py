from typing import List
from .. import board2d as b
from .. import non_euclid_board as nb
from . import console as c


class BoardReader(c.PageContent):
    data: b.Board2D

    def __init__(self, board: b.Board2D, x_pos: int, y_pos: int, wall: str = "X", floor: str = "_",
                 void: str = " ", player: str = "O", win: str = "1"):
        super(BoardReader, self).__init__(board)
        self.wall = wall
        self.floor = floor
        self.void = void
        self.player = player
        self.x_pos = x_pos
        self.y_pos = y_pos
        self.win = win

    def str_field(self, f: b.Field):
        # noinspection PyTypeHints
        f.data: nb.FieldInfo
        t = f.data.simpled_texture_type
        if t == nb.SimpledTexturesType.wall:
            return self.wall
        elif t == nb.SimpledTexturesType.floor:
            return self.floor
        elif t == nb.SimpledTexturesType.void:
            return self.void
        elif t == nb.SimpledTexturesType.win:
            return self.win

    def get_board(self) -> b.Board2D:
        return self.data

    def get(self):
        ret: List[List[str]] = []
        b_it = b.Board2DRowsIterator(self.get_board())
        y = 0
        for r in b_it:
            ret.append([])
            for f in r:
                ret[y].append(self.str_field(f))
            y += 1
        try:
            ret[self.y_pos][self.x_pos] = self.player
            return ret
        except IndexError:
            return ret

    def __str__(self):
        g = self.get()
        r = ""
        for li in g:
            for f in li:
                r += f
            r += "\n"
        return r
