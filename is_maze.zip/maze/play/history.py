from typing import Optional, Union, Any


class History:
    """
    Class to cache history of editing
    """

    def __init__(self):
        self.history = Edit(None)
        self.current = self.history

    def undo(self):
        """
        Undo
        :return: None
        """
        self.current = self.current.undo()

    def redo(self):
        """
        Redo
        :return: None
        """
        self.current = self.current.redo()

    def get(self):
        """
        Get current
        :return: any saved value
        """
        return self.current.get()

    def edit(self, obj):
        """
        Saves to history
        :param obj: object to save
        :return:
        """
        self.current = self.current.edit(obj)

    def last(self):
        """
        Return last object
        Doesn't undo
        :return: last
        """
        return self.current.last.obj

    def next(self):
        """
        Return next object
        Doesn't redo
        :return: next object
        """
        return self.current.next.obj

    def back(self):
        """
        Undo + get new current
        :return: new current
        """
        self.undo()
        return self.get()

    def forward(self):
        """
        Redo + get new current
        :return: new current
        """
        self.redo()
        return self.get()


class Edit:
    """
    Class used by class History
    """

    def __init__(self, obj: Optional[Any] = None):
        self.obj = obj
        self.last: Optional["Edit"] = None
        self.next: Optional["Edit"] = None

    def undo(self):
        if self.last:
            return self.last
        return self

    def redo(self):
        if self.next:
            return self.next
        return self

    def set(self, obj: "Edit"):
        self.next = obj
        obj.connect(self)

    def edit(self, obj: Union["Edit", Any], make_new: bool = True):
        if make_new:
            self.set(Edit(obj))
        else:
            self.set(obj)
        return self.next

    def connect(self, other):
        self.last = other

    def get(self):
        return self.obj
