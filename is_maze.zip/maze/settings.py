from typing import Union, List, Tuple, Set, Dict


version = "0.0.1"
title = "alpha console edition"
render_distance = 4
levels: Dict[str, Tuple[int, int]] = {
    "level.json": (0, 0),
    "level2.json": (0, 0),
    "level3.json": (0, 0),
    "level4.json": (0, 0),
    "level5.json": (0, 0)
}


def check_version(ver: Union[str, int, List[str], Tuple[str], Set[str]]) -> bool:
    if isinstance(ver, str):
        return ver == version
    elif isinstance(ver, int):
        return str(ver) == version
    elif isinstance(ver, (list, tuple, set)):
        return version in ver
    else:
        raise ValueError("Incorrect version type")
